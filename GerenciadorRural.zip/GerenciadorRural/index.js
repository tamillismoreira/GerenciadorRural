const express = require('express');
const bodyParser = require('body-parser');
const conexao = require('./bd/conexao');
const Desembolsos_lavouras = require('./bd/Desembolsos_lavouras');
const Propriedades = require('./bd/Propriedades');
const Receita_lavouras = require('./bd/Receita_lavouras');
const Lavouras = require('./bd/Lavouras');
const Usuarios = require('./bd/Usuarios');
const app = express();
const bcrypt = require('bcryptjs');

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: false}));
app.set("view engine", "ejs");

conexao.authenticate();

app.get("/", function(req, res){
    res.render("login", {mensagem: ""});
});


app.get("/index", function(req, res){
    res.render("index");
});

app.post('/login', function(req, res){
    Usuarios
        .findOne({where: {email: req.body.login}})
        .then( function(usuario){
            if(usuario != undefined){
                if(usuario.senha == req.body.senha){
                    res.redirect("/index");
                }
                else
                res.render("login", {mensagem: "Usuário ou senha inválidos"});
            }
            else
            res.render("login", {mensagem: "Usuário ou senha inválidos"});
        });
});

app.get("/usuarios/novo", function(req, res){
    res.render("usuarios");
});

app.post("/usuarios/salvar", function(req, res){
    let nome = req.body.nome;
    let senha = req.body.senha;
    let email = req.body.login;

    let salt = bcrypt.genSaltSync(10);
    let senhaCripto = bcrypt.hashSync(senha, salt);

    Usuarios
        .create({ nome: nome, email: email, senha: senhaCripto})
        .then(
            res.render("login", {mensagem: "Usuário Cadastrado"})
        );
});

app.get("/receita_pecuarias", function(req, res){
    res.render("receita_pecuarias/receita_pecuarias");
});

app.get("/receita_lavouras", function(req, res){
    res.render("receita_lavouras/receita_lavouras");
});

app.get("/custos_administrativos", function(req, res){
    res.render("custos_administrativos/custos_administrativos");
});


app.get("/custos_administrativos/novo", function(req, res){
    res.render("custos_administrativos/novo", {mensagem: ""});
});

app.get("/desembolsos_pecuaria", function(req, res){
    res.render("desembolsos_pecuaria/novo", {mensagem:""});
});

app.get("/desembolsos_pecuaria", function(req, res){
    res.render("desembolsos_pecuaria/desembolsos_pecuaria");
});

app.get("/desembolsos_lavouras", function(req, res){
    Desembolsos_lavouras
    .findAll({order: ["impostofunrural"] })
    .then(function(desembolsos_lavouras){
        res.render("desembolsos_lavouras/desembolsos_lavouras",{desembolsos_lavouras: desembolsos_lavouras});
    });
      
});

app.get("/desembolsos_lavouras/novo", function(req, res){
    res.render("desembolsos_lavouras/novo", {mensagem: ""});
})

app.post("/desembolsos_lavouras/salvar", function(req, res){
    let manutencao = req.body.manutencao;
    let impostofunrural = req.body.impostofunrural;
    let adubo = req.body.adubo;
    let sementes = req.body.sementes;
    let defensivos = req.body.defensivos;
    let aviacao = req.body.aviacao;
    let custoha = req.body.custoha;
    let total = req.body.total;
    Desembolsos_lavouras
        .create({manutencao: manutencao, impostofunrural: impostofunrural, adubo: adubo,
        sementes: sementes, defensivos: defensivos, aviacao: aviacao,
        custoha: custoha, total: total})
        .then (
           res.render("desembolsos_lavouras/novo", {mensagem: "Desembolso incluído"}
       ));
    });

app.get("/desembolsos_lavouras/editar/:id", function(req, res){
    let id = req.params.id;
    Desembolsos_lavouras
        .findByPk(id)
        .then(function(desembolso_lavoura){
            res.render("desembolsos_lavouras/editar", {desembolso_lavoura: desembolso_lavoura});
        });
});
app.post("/desembolsos_lavouras/atualizar", function (req, res) {
    let id = req.body.id;
    let manutencao = req.body.manutencao;
    let impostofunrural = req.body.impostofunrural;
    let adubo = req.body.adubo;
    let sementes = req.body.sementes;
    let defensivos = req.body.defensivos;
    let aviacao = req.body.aviacao;
    let custoha = req.body.custoha;
    let total = req.body.total;
    Desembolsos_lavouras
        .update({ manutencao: manutencao, impostofunrural: impostofunrural, adubo: adubo, sementes: sementes, defensivos: defensivos,
                 aviacao: aviacao, custoha: custoha, total: total }, { where: { id: id } })
        .then(function () {
            res.redirect("/desembolsos_lavouras");
        });
});

app.get("/desembolsos_lavouras/excluir/:id", function(req, res){
    let id = req.params.id;
    Desembolsos_lavouras
        .destroy({where: {id: id} })
        .then(function(){
            res.redirect("/desembolsos_lavouras")
        });
});

app.get("/lavouras", function(req, res){
    Lavouras
        .findAll({order: ["proprietario_terra"], include: [{model: Receita_lavouras,}], 
                        include:[{model: Propriedades}], include:[{model:Desembolsos_lavouras}] })
                        .then(function(lavouras){
                            res.render("lavouras/lavouras", {lavouras: lavouras});

                        });
    });


app.post("/lavouras/salvar", function(req, res){
    let periodo_avaliacao_inicio = req.body.periodo_avaliacao_inicio;
    let proprietario_terra = req.body.proprietario_terra;
    let valor_arrendamento = req.body.valor_arrendamento;
    let taxa_juros_mensal = req.body.taxa_juros_mensal;
    let prazo_medio = req.body.prazo_medio;
    let area_utilizada = req.body.area_utilizada;
    let preco_saco = req.body.preco_saco;
    let quantidade_sacos = req.body.quantidade_sacos;
    let produtividade = req.body.produtividade;
    let desembolso_lavoura = req.body.desembolso_lavoura;
    let receita_lavoura = req.body.receita_lavoura;
    let propriedade = req.body.propriedade;
    Lavouras 
     .create({periodo_avaliacao_inicio: periodo_avaliacao_inicio, proprietario_terra: proprietario_terra, valor_arrendamento: valor_arrendamento, 
              taxa_juros_mensal: taxa_juros_mensal, prazo_medio: prazo_medio, area_utilizada: area_utilizada,
              preco_saco: preco_saco, quantidade_sacos: quantidade_sacos, produtividade: produtividade, 
              desembolso_lavouraId: desembolso_lavoura, receita_lavouraId: receita_lavoura, propriedadeId: propriedade })
              .then(
                  res.redirect("/lavouras/novo/incluido")
              );
});

app.get("/lavouras/novo/:mensagem?", function(req, res){
    Desembolsos_lavouras
    .findAll({order: ["total"] })
    .then(function(desembolsos_lavouras){
        Receita_lavouras
            .findAll({order: ["custo_total"] })
            .then(function (receita_lavouras){
                Propriedades
                .findAll({order: ["nome_propriedade"] })
                .then(function (propriedades){
                    if (req.params.mensagem)
                    res.render("lavouras/novo", {
                        mensagem: "Lavoura Incluída", desembolsos_lavouras: desembolsos_lavouras,
                        receita_lavouras: receita_lavouras,
                        propriedades: propriedades
                    });
                    else
                        res.render("lavouras/novo", {
                            mensagem:"", desembolsos_lavouras: desembolsos_lavouras,
                            receita_lavouras: receita_lavouras,
                            propriedades: propriedades
                        });
                });
            });
        
        });
      });
    
   app.get("/receita_lavouras", function(req, res){
    Receita_lavouras
    .findAll({order: ["depreciacao"] })
    .then(function(receita_lavouras){
        res.render("receita_lavouras/receita_lavouras",{receita_lavouras: receita_lavouras});
    });
      
});


app.get("/receita_lavouras/novo", function(req, res){
    res.render("receita_lavouras/novo", {mensagem: ""});
})


app.post("/receita_lavouras/salvar", function(req, res){
    let depreciacao = req.body.depreciacao;
    let custo_oportunidade_terra = req.body.custo_oportunidade_terra;
    let custo_oportunidae_capital = req.body.custo_oportunidae_capital;
    let custo_total = req.body.custo_total;
    let custo_ha = req.body.custo_ha;
    
    Receita_lavouras
        .create({depreciacao: depreciacao, custo_oportunidade_terra: custo_oportunidade_terra,
        custo_oportunidae_capital: custo_oportunidae_capital, custo_total: custo_total, custo_ha: custo_ha})
        .then (
            res.render("receita_lavouras/novo", {mensagem: "Receita da Lavoura incluída"}
        ));
});

app.get("/receita_lavouras/editar/:id", function(req, res){
    let id = req.params.id;
    Receita_lavouras
        .findByPk(id)
        .then(function(receita_lavoura){
            res.render("receita_lavouras/editar", {receita_lavoura: receita_lavoura});
        });
});

app.post("/receita_lavouras/atualizar", function(req, res){
    let id = req.body.id;
    let custo_oportunidade_terra = req.body.custo_oportunidade_terra;
    let custo_total = req.body.custo_total;
    let custo_ha = req.body.custo_ha;

    Receita_lavouras
        .update({custo_oportunidade_terra: custo_oportunidade_terra, custo_total: custo_total, custo_ha: custo_ha}, {where:{id: id} })
        .then(function(){
            res.redirect("/receita_lavouras");
        });
});

app.get("/receita_lavouras/excluir/:id", function(req, res){
    let id = req.params.id;
    Receita_lavouras
        .destroy({where: {id: id} })
        .then(function(){
            res.redirect("/receita_lavouras")
        });
});

app.get("/propriedades", function(req, res){
    Propriedades
    .findAll({order: ["nome_propriedade"] })
    .then(function(propriedades){
        res.render("propriedades/propriedades", {propriedades: propriedades});
    });
  });

app.get("/propriedades/novo", function(req, res){
    res.render("propriedades/novo", {mensagem: ""});
})

app.post("/propriedades/salvar", function(req, res){
    let nome_propriedade = req.body.nome_propriedade;
    let area_total_propriedade = req.body.area_total_propriedade;
      
    
    Propriedades
        .create({nome_propriedade: nome_propriedade, area_total_propriedade: area_total_propriedade})
        .then (
           res.render("propriedades/novo", {mensagem: "Propriedade incluída"}
       ));
    });

    app.get("/propriedades/editar/:id", function(req, res){
        let id = req.params.id;
        Propriedades
            .findByPk(id)
            .then(function(propriedade){
                res.render("propriedades/editar", {propriedade: propriedade});
            });
    });

    app.post("/propriedades/atualizar", function(req, res){
        let id = req.body.id;
        let nome_propriedade = req.body.nome_propriedade;
        let area_total_propriedade = req.body.area_total_propriedade;
        

        Propriedades
            .update({nome_propriedade: nome_propriedade, area_total_propriedade: area_total_propriedade}, {where: {id: id} })
            .then(function(){
                res.redirect("/propriedades");
            });
    });


    app.get("/propriedades/excluir/:id", function(req, res){
        let id = req.params.id;
        Propriedades
            .destroy({where: {id: id} })
            .then(function(){
                res.redirect("/propriedades")
            });
    });

app.listen(3000);