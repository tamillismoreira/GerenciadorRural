const Sequelize = require('sequelize');
const conexao = require('./conexao');
const Propriedades = require('./Propriedades');

const Custos_administrativos = conexao('Custos_administrativos',{
    id:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    aluguel: Sequelize.FLOAT,
    luz: Sequelize.FLOAT,
    telefone: Sequelize.FLOAT,
    manutencao_carros: Sequelize.FLOAT,
    combustivel_carros: Sequelize.FLOAT,
    impostos_comuns: Sequelize.FLOAT,
    salario_administrador: Sequelize.FLOAT,
    equipamentos_informatica: Sequelize.FLOAT,
    comissao_funcionarios: Sequelize.FLOAT,
    total_anual: Sequelize.FLOAT,
    outros: Sequelize.FLOAT
});

Custos_administrativos.belongsTo(Propriedades);

Custos_administrativos.sync({force: false});

module.exports = Custos_administrativos;