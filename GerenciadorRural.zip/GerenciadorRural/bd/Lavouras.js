const Sequelize = require('sequelize');
const conexao = require('./conexao');
const Receita_lavouras = require('./Receita_lavouras');
const Desembolsos_lavouras = require('./Desembolsos_lavouras');
const Propriedades = require('./Propriedades');

const Lavouras = conexao.define('Lavouras', {
    id:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    
    periodo_avaliacao_inicio: Sequelize.DataTypes.DATEONLY,
    proprietario_terra: Sequelize.STRING,
    valor_arrendamento: Sequelize.FLOAT,
    taxa_juros_mensal: Sequelize.FLOAT,
    prazo_medio: Sequelize.FLOAT,
    area_utilizada: Sequelize.INTEGER,
    preco_saco: Sequelize.FLOAT,
    quantidade_sacos: Sequelize.INTEGER,
    produtividade: Sequelize.FLOAT
});

Lavouras.belongsTo(Propriedades);
Lavouras.belongsTo(Receita_lavouras);
Lavouras.belongsTo(Desembolsos_lavouras);

Lavouras.sync({force: false});

module.exports = Lavouras;