const Sequelize = require('sequelize');
const conexao = require('./conexao');

const Receita_lavouras = conexao.define('Receita_lavouras',{
    id:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    depreciacao: Sequelize.FLOAT,
    custo_oportunidade_terra: Sequelize.FLOAT,
    custo_total: Sequelize.FLOAT,
    custo_ha: Sequelize.FLOAT
});

Receita_lavouras.sync({force: false});

module.exports = Receita_lavouras;