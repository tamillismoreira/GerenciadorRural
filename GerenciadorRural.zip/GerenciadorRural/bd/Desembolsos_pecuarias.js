const Sequelize = require('sequelize');
const conexao = require('./conexao');

const Desembolsos_pecuarias = conexao.define('Desembolsos_pecuarias',{
    id:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
     
    impostofunrural_dpecuaria: Sequelize.FLOAT,
    compra_animais: Sequelize.FLOAT,
    medicamentos: Sequelize.FLOAT,
    sal_mineral: Sequelize.FLOAT,
    racoes: Sequelize.FLOAT,
    manutencao_dpecuaria: Sequelize.FLOAT,
    mao_de_obra: Sequelize.FLOAT,
    adubo_dpecuaria: Sequelize.FLOAT,
    sementes_dpecuaria: Sequelize.FLOAT,
    defensivos_dpecuaria: Sequelize.FLOAT,
    combustivel_dpecuaria: Sequelize.FLOAT,
    aviacao_dpecuaria: Sequelize.FLOAT,
    custototal_dpecuaria: Sequelize.FLOAT,
    custoha_dpecuaria: Sequelize.FLOAT
});

Desembolsos_pecuarias.sync({force: false});
module.exports = Desembolsos_pecuarias;