const Sequelize = require('sequelize');
const conexao = require('./conexao');

const Desembolsos_lavouras = conexao.define('Desembolsos_lavouras',{
    id:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
     
    manutencao: Sequelize.FLOAT,
    impostofunrural: Sequelize.FLOAT,
    adubo: Sequelize.FLOAT,
    sementes: Sequelize.FLOAT,
    defensivos: Sequelize.FLOAT,
    aviacao: Sequelize.FLOAT,
    custoha: Sequelize.FLOAT,
    total: Sequelize.FLOAT
});

Desembolsos_lavouras.sync({force: false});
module.exports = Desembolsos_lavouras;
