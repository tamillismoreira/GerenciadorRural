const Sequelize = require('sequelize');
const conexao = require('./conexao');

const Propriedades = conexao.define('Propriedades', {
    id:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    nome_propriedade: Sequelize.STRING,
    area_total_propriedade: Sequelize.FLOAT,
});

Propriedades.sync({force: false});

module.exports = Propriedades;